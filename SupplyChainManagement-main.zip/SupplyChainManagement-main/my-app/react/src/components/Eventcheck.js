import React from 'react';

function Eventcheck(props) {
    const handleSubmit=()=>{
    }
    const handleSubmit2=(e)=>{
    }
    return (
        <div className="row align-items-center g-lg-5 py-5">
            <div className='col'>
                <img src='https://blog.thomasnet.com/hs-fs/hubfs/shutterstock_774749455.jpg?width=900&name=shutterstock_774749455.jpg' />
            </div>
            <div className="col">
                <a href='/'><button className='btn btn-outline-primary'>Login</button></a>
            </div>
        </div>
       
    );
}

export default Eventcheck;